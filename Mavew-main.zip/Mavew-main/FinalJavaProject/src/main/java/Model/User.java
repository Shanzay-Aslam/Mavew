package Model;

public class User {

}
